package com.example.relaystore;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvLogin;
    TextView tvBackPress;
    Button btnRegister;
    EditText etName, etEmail, etPassword, etConformPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        tvLogin = findViewById(R.id.tv_login);
        tvBackPress = findViewById(R.id.tv_back_press);
        btnRegister = findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Account_verification.class);
                startActivity(intent);


               /* String name = etName.getText().toString().trim();
                final String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                String conform_password = etConformPassword.getText().toString().trim();


                //for set error msg on edittexts...
                if (Name.isEmpty() || contact.length() < 10) {
                    editTextMobile.setError("Enter a valid mobile");
                    editTextMobile.requestFocus();
                    return;
                }

                if (name.isEmpty()){
                    etName.setError("Enter Your Name!");
                    etName.requestFocus();
                }

                //for set valid email address
                if (email.isEmpty() || (!email.matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+"))) {
                    etEmail.setError("Invalid Email Address!");
                    etEmail.requestFocus();
                    return;
                }


                if (password.isEmpty()) {
                    etPassword.setError("Enter Password!");
                    etPassword.requestFocus();
                    return;
                }

                if (conform_password.isEmpty()) {
                    etConformPassword.setError("Re-Enter Password!");
                    etConformPassword.requestFocus();
                    return;
                }*/
            }
        });

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        tvBackPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }
}
