package com.example.relaystore;

import android.content.Intent;
import android.drm.DrmStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class Choose_payment_method extends AppCompatActivity {
    Button btn_Perform_payment;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_payment_method);

        ActionBar actionBar =getSupportActionBar();
        actionBar.hide();

        btn_Perform_payment = findViewById(R.id.btn_Perform_payment);
        btn_Perform_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Choose_payment_method.this,Order_Finalisation_Activity.class);
                startActivity(intent);

            }
        });


 }
}
