package com.example.relaystore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class Forgot_Activity extends AppCompatActivity {

   // TextView tvValidate;
    TextView tvBackPress;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_password);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        tvBackPress = findViewById(R.id.tv_back_press);
        tvBackPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

/*
        tvValidate = findViewById(R.id.btn_validate);
        tvValidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Forgot_Activity.this,Account_verification.class);
                startActivity(intent);
            }
        });*/
    }
}
